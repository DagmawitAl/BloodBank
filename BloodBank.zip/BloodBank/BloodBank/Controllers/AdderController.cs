﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BloodBank.Models;
using Microsoft.AspNetCore.Mvc;

namespace BloodBank.Controllers
{
    public class AdderController : Controller
    {
        public IActionResult AddDonorView()
        {
            Donor donor = new Donor();
            int donId = donor.GenerateDonorID();
            Donor d = new Donor { DonorID = donId };
            return View(d);
            
        }

        public IActionResult AddDonor(Donor donor)
        {
            Donor d = new Donor();

            d.AddDonor(donor.DonorID, donor.FirstName, donor.LastName, donor.Age, donor.Sex, donor.Address, donor.BloodID);
            List<Donor> donors = d.ListDonors();
            return View("../Adder/ListDonorsView", donors);
            //return Content("-- "+donor.DonorID+donor.FirstName+donor.Sex);
        }

        [HttpGet]
        public IActionResult ListDonors()
        {
            //BothDonorAndRequest both = new BothDonorAndRequest();
            Donor donor = new Donor();

            //both.Donor = donor;
            List<Donor> donors = donor.ListDonors();
            return View("../Adder/ListDonorsView", donors);
            //return Content("-- " + id);
        }
    }
}