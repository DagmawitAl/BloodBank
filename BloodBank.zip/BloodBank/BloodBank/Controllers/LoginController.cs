﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BloodBank.Models;
using Microsoft.AspNetCore.Mvc;

namespace BloodBank.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Adder adder) {
            if (ModelState.IsValid)
            {
                Donor donor = new Donor();
                int donId = donor.GenerateDonorID() + 2;
                Donor d = new Donor { DonorID = donId };
                return View("../Adder/AddDonorView", d);
            }
            return View("login");
        }
    }
}