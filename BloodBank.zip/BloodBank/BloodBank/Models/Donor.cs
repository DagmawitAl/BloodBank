﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BloodBank.Models
{
    public class Donor
    {
        public int DonorID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }
        public string Sex { get; set; }
        public string Address { get; set; }
        public int BloodID { get; set; }
        public DateTime dateTime { get; set; }

        public int GenerateDonorID()
        {
            return Utility.db.GenerateDonorID();
        }

        public List<Donor> ListDonors()
        {
            return Utility.db.ListDonors();
        }
        public void AddDonor(int donorId, string firstName, string lastName, int age, string sex, string address, int bloodId)
        {
            Utility.db.AddDonor(donorId, firstName, lastName, age, sex, address, bloodId);
        }
    }
}
