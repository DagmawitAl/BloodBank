﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace BloodBank.Models
{
    public class Adder
    {
        [Required]
        public string UserID { get; set; }
        [Required]
        public string Password { get; set; }

        public string Login(string userID, string password)
        {
            return Utility.db.Login(userID, password);

        }
    }
}
