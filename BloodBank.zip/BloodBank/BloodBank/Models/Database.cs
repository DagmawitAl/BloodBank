﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace BloodBank.Models
{
    public class Database
    {
        MySqlConnection sqlCon;
        public Database()
        {
            string connectionString = "Server=localhost;Database=bloodbank;Uid=root;Pwd=;";
            this.sqlCon = new MySqlConnection(connectionString);
            sqlCon.Open();
        }

        public string Login(string userID, string password)
        {

            using (var sqlCmd = sqlCon.CreateCommand())
            {
                sqlCmd.CommandText = "SELECT COUNT(*) as count,EmployeeType as role FROM employee " +
                    "WHERE employee.EmployeeID = @UserID AND employee.Password = @Password LIMIT 1";
                sqlCmd.Parameters.AddWithValue("@UserID", userID);
                sqlCmd.Parameters.AddWithValue("@Password", password);
                using (var reader = sqlCmd.ExecuteReader())
                {
                    reader.Read();
                    int y = reader.GetInt32("count");
                    string roleReturn = "";
                    if (y == 1)
                    {
                        string role = reader.GetString("role");
                        //if (role == "Admin")
                        //{
                        //    ////user.Role = "admin";
                        //    //Console.WriteLine("Successful");
                        //    //val = true;
                        //    roleReturn = "Admin";
                        //}
                        ////sqlCmd.CommandText = "SELECT Role FROM user";

                        //else if (role == "Tester")
                        //{
                        //    Console.WriteLine("Successful");
                        //    roleReturn = "Tester";
                        //}
                        if (role == "Adder")
                        {
                            roleReturn = "Adder";
                        }
                        else
                        {
                            roleReturn = "none";
                            //Console.WriteLine("Failed");
                        }

                    }
                    return roleReturn;
                }
            }
        }

        int donId;
        public int GenerateDonorID()
        {
            using (var sqlCmd = sqlCon.CreateCommand())
            {
                sqlCmd.CommandText = "SELECT COUNT(DonorID) FROM donor";
                donId = Convert.ToInt32(sqlCmd.ExecuteScalar());
                donId++;
                new Donor { DonorID = donId };
                //warehouse.ID = wareID + id.ToString();
            }
            return donId;
        }

        public void AddDonor(int donorId, string firstName, string lastName, int age, string sex, string address, int bloodId)
        {
            using (var sqlCmd = sqlCon.CreateCommand())
            {
                sqlCmd.CommandText = $"INSERT INTO donor (`DonorID`,`First Name`,`Last Name`,`Age`," +
                    $"`Sex`,`Address`,BloodID) VALUES ('{donorId}','{firstName}','{lastName}','{age}','{sex}'," +
                    $"'{address}','{bloodId}')";
                using (var reader = sqlCmd.ExecuteReader())
                {
                    reader.Read();
                    var x = reader.FieldCount;
                    for (int i = 0; i < x; i++)
                    {
                        if (reader[i] is DBNull)
                        {
                            System.Console.WriteLine("It's null");
                        }
                        else
                        {
                            System.Console.WriteLine(reader[i].ToString());
                        }
                    }
                }
            }
        }

        public List<Donor> ListDonors()
        {
            using (var sqlCmd = sqlCon.CreateCommand())
            {
                sqlCmd.CommandText = $"SELECT * FROM donor";
                var donors = new List<Donor>();
                using (var reader = sqlCmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            donors.Add(
                                new Donor
                                {
                                    DonorID = reader.GetInt32("DonorID"),
                                    FirstName = reader.GetString("First Name"),
                                    LastName = reader.GetString("Last Name"),
                                    Age = reader.GetInt32("Age"),
                                    Sex = reader.GetString("Sex"),
                                    Address = reader.GetString("Address")
                                }
                            );
                        }

                    }

                }
                return donors;
            }
        }

    }
}
